# B104D compact reference pack

This pack contains only compact, previously verified derivatives needed by `screen_goa_release_date_range.py`. It excludes raw GraphSAGE, GOA, ontology, and gp2protein source archives.

The historical mapping file preserves many-to-many GeneID–UniProt edges. The corrected GPI159 edge file records the component-aware resolution used in the exact reconstruction, including removal of the unsafe O95073→25788 projection.
